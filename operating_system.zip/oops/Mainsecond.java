import java.util.*;
class Reverse
{
   public static int find(int num)
   {
      int a=0;
      while(num!=0)
      {
         a=10*a+num%10;
         num=num/10;
      }
      return a;
   }

}
class ReverseR extends Reverse{

   static int temp=0;
   public static int find(int num)
   {

      temp=temp*10+num%10;
      if(num/10!=0)
      {
         temp=find(num / 10);
      }
      return temp;
   }
}
public class Mainsecond
{
   public static void main(String[] args) {
      Reverse og=new Reverse();
      ReverseR fg=new ReverseR();
      Scanner ob=new Scanner(System.in);
      System.out.println("Input test case");
      int test=ob.nextInt();
      System.out.println("Using while loop in Reverse class");
      System.out.println(og.find(test));
      System.out.println("Using recursion in ReverseR");
      System.out.println(fg.find(test));
   }
}