public class runnableinterface {
    public static void main(String args[]) {

Thread t1 = new Thread(new T1());
Thread t2 = new Thread(new T2());
t1.run();
t2.run();

    }
    }
    
  class T1 implements Runnable{
     public void run( ) {
        int a[][]={{4,4},{5,5}};  
        int b[][]={{1,2},{2,1}};  
        int c[][]=new int[2][2];
 
System.out.println("Addition of two matrix given is .......");
        for(int i=0;i<2;i++){  
               for(int j=0;j<2;j++){  
                    c[i][j]=a[i][j]+b[i][j];  
                 System.out.print(c[i][j]+" ");  
                   
               }  
               System.out.println();  
           
        }
     }
}

class T2 implements Runnable {
     public void run( ) {
         int a[][]={{1,1},{2,2}};    
         int b[][]={{2,2},{3,3}};    
   
   
          int c[][]=new int[2][2];   
 System.out.println("multiple of two matrix given matrix is.... :");
          for(int i=0;i<2;i++){    
                for(int j=0;j<2;j++){    
                    c[i][j]=0;      
                    for(int k=0;k<2;k++)      
                    {      
                        c[i][j]+=a[i][k]*b[k][j];      
                       
                    }  
                    System.out.print(c[i][j]+" ");  
                   
                }
                System.out.println();
                }    
     }
}

