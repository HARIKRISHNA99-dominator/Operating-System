import java.util.*;
class generic<Number extends Comparable<Number>>{
Number array[];
generic(number array[]){
array = array;
}
static Number Max(){
           int max;
           for(int i=1;i<array.length;i++){
           if(max < array[i]){
           max = array[i];

}
return max;
}
}
public class GenericArray{
public static void main(String args[]){
generic<integer> genericone = new generic<integer>(new integer[]{10,20,30,40,50});
System.out.println("max :" + genericone.Max());


 }
}