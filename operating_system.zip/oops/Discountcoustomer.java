import java.util.*;
class Customer{
  String name;
  boolean member = false;
  String memberType;
  public Customer(String n){
    name = n;
    memberType="";
  }
  public String getName(){
    return(name);
  }
  public boolean isMember(){
    return(member);
  }
  public void setMember(boolean m){
    if(m==true){
      member=true;
    }
  }
  public String getMemberType(){
    return(memberType);
  }
  public void setMemberType(String s){
    memberType=s;
  }
  public String toString(){
    System.out.println("Name: " + name);
    System.out.println("Member Type " + memberType);
    return("");
  }
}


class Visit {
  Scanner sc = new Scanner(System.in);

  Customer customer = new Customer(" ");
  Date date = new Date();
  double serviceExpense;
  double productExpense;
  
  public Visit(String n, Date d){
    customer.name = n;
    date = d;
    String type1=" ";
    serviceExpense=0.0;
    productExpense=0.0;
    double serviceRate;
    double prodRate;
    double total=0;
    DiscountRate d1 = new DiscountRate();
    System.out.println("Enter Service Expense");
    serviceExpense = sc.nextDouble();
    System.out.println("Enter Product Expense");
    productExpense = sc.nextDouble();
    System.out.println("Are you a member? (y/n)");
    char ch = sc.next().charAt(0);
    if(ch == 'y')
    {
      d1 = new DiscountRate();
      customer.member = true;
      System.out.println("Enter the member type: ");
      Scanner sc = new Scanner(System.in);
      type1 = sc.nextLine();
      customer.memberType = type1;
      System.out.println("Membership type = " + customer.getMemberType());
      serviceRate = d1.getServiceDiscountRate(type1);
      prodRate = d1.getProductDiscountRate(type1);    
    } else {
      serviceRate=0.0;
      prodRate=0;
    }
    total = serviceExpense + productExpense - (serviceExpense*serviceRate + productExpense*prodRate);
    System.out.println("Total cost" + total);
  }
  public String getName(){
    return(customer.name);
  }
  public double getServiceExpense(){
    return(serviceExpense);
  }
  public void setServiceExpense(double ex){
    serviceExpense = ex;
  }
  public double getProductExpense(){
    return (productExpense);
  }
  public void setProductExpense(double ex){
    productExpense = ex;
  }
  public double getTotalExpense(){
    double totalExpense = serviceExpense + productExpense;
    return(totalExpense);
  }
  public String toString(){
    return("");
  }
}

class DiscountRate{
  double serviceDiscountPremium = 0.2;
  double serviceDiscountGold = 0.15;
  double serviceDiscountSilver = 0.1;
  double productDiscountPremium = 0.1;
  double productDiscountGold = 0.1;
  double productDiscountSilver = 0.1;
  
  public double getServiceDiscountRate(String type){
    if(type.equals("gold"))
      return serviceDiscountGold;
    if (type.equals("silver"))
      return serviceDiscountSilver;
    if(type.equals("premium"))
      return serviceDiscountPremium;
    return (0.0);
  }
  public double getProductDiscountRate(String type){
    if(type.equals("gold"))
      return productDiscountGold;
    if (type.equals("silver"))
      return productDiscountSilver;
    if(type.equals("premium"))
      return productDiscountPremium;
    return (0.0);  
  }
}

public class Discountcoustomer {
  public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    String name1;
    System.out.println("Enter name: ");
    name1 = sc.nextLine();
    Date d = new Date();
    Visit v1 = new Visit(name1, d);
    
  }
}