
class Sem1{
	int m1,m2,m3,m4;
	double avg1;
	Sem1(int m1,m2,m3,m4){
		this.m1 = m1;
		this.m2 = m2;
		this.m3 = m3;
		this.m4 = m4;
		
		avg1 = (m1+m2+m3+m4)/4;
	}
}
class Sem2 extends Sem1{
	int c1,c2,c3,c4;
	double avg2;
	Sem2(int m1, int m2, int m3, int m4,int c1,int c2,int c3, int c4) {
		super(m1, m2, m3, m4);
		this.c1 = c1;
		this.c2 = c2;
		this.c3 = c3;
		this.c4 = c4;
		
		avg2 = (c1+c2+c3+c4)/4; 
		
	}
	
}
class Sem3 extends Sem2{
	int a1,a2,a3,a4;
	double avg3;
	Sem3(int m1, int m2, int m3, int m4, int c1, int c2, int c3, int c4,int a1, int a2, int a3, int a4) {
		super(m1, m2, m3, m4, c1, c2, c3, c4);
		this.a1 = a1;
		this.a2 = a2;
		this.a3 = a3;
		this.a4 = a4;
		
		avg3 = (a1+a2+a3+a4)/4;
		
	}
	
}
class Sem4 extends Sem3{
	int b1,b2,b3,b4;
	double avg4, total_avg;
	Sem4(int m1, int m2, int m3, int m4, int c1, int c2, int c3, int c4, int a1, int a2, int a3, int a4, int b2, int b1, int b3, int b4) {
		super(m1, m2, m3, m4, c1, c2, c3, c4, a1, a2, a3, a4);
		this.b1 = b1;
		this.b2 = b2;
		this.b3 = b3;
		this.b4 = b4;
		avg4 = (b1+b2+b3+b4)/4;
		total_avg = (avg1+avg2+avg3+avg4)/4;
		System.out.println("Sem1 avg is :"+avg1);
		System.out.println("Sem2 avg is :"+avg2);
		System.out.println("Sem3 avg is :"+avg3);
		System.out.println("Sem4 avg is :"+avg4);
		System.out.println("Total avg of all Sem is"+total_avg);
	}
	
}

public class idiot {

	public static void main(String[] args) {
		
		new Sem4(50, 30, 45, 46, 52, 42, 48, 47, 40, 25, 40, 37, 39, 45, 43, 51);

	}

}