import java.util.*;
 class Matrix{
    int m;
    int n;
    int matrix[][];
    Matrix(int m,int n){
       this.m=m;
       this.n=n;
       matrix=new int[m][n];
       for(int i=0;i<m;i++){
          for(int j=0;j<n;j++){
             matrix[i][j]=0;
          }
       }
    }
    public int[][] MatrixProduct(Matrix x){
       int a[][]=new int[m][x.matrix[0].length];
       if(n==x.matrix.length) {
          for(int i=0;i<m;i++){
             for(int j=0;j<x.n;j++){
                a[i][j]=0;
                for(int k=0;k<n;k++){
                  a[i][j]=a[i][j]+(matrix[i][k]*x.matrix[k][j]);
                }
             }
          }
          return a;
       }
       else{
          return null;
       }
    }
    public boolean check(Matrix x){
       if(n!=x.matrix.length){
          try{
            throw new ExceptionWrongMatrixDimension();
          }
          catch (ExceptionWrongMatrixDimension e){
             return false;
          }
       }
       else{
          return true;
       }
    }
 }
 class ExceptionWrongMatrixDimension extends Exception{

 }
   public class MatrixMain {
      public static void main(String[] args) {
         Scanner ob = new Scanner(System.in);
         System.out.println("Size of matrix 1 and matrix 2");
         int s1 = ob.nextInt();
         int s2 = ob.nextInt();
         int s3 = ob.nextInt();
         int s4 = ob.nextInt();
         Matrix sd = new Matrix(s1, s2);
         int y[][] = new int[s3][s4];
         System.out.println("Your matrix");
         for (int i = 0; i < s3; i++) {
            for (int j = 0; j < s4; j++) {
               y[i][j] = ob.nextInt();
            }
         }
         System.out.println("Matrix for the class");
         for (int i = 0; i < s1; i++) {
            for (int j = 0; j < s2; j++) {
               sd.matrix[i][j] = ob.nextInt();
            }
         }
         Matrix xd = new Matrix(s3, s4);
         xd.matrix = y;
         int a[][] = sd.MatrixProduct(xd);
         if (sd.check(xd)) {
            System.out.println("The product of matrices are (class matrix multiplied by your matrix):");
            for (int i = 0; i < s3; i++) {
               for (int j = 0; j < s4; j++) {
                  System.out.print(" " + a[i][j] + " ");
               }
               System.out.println();
            }
         }
         else{
            System.out.println("Multiplication is not valid");
         }
      }
   }