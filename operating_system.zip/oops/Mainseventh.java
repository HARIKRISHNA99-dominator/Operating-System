import java.util.*;
interface GeometricFigure
{
   abstract void area();
   abstract void setDimensions();
   Scanner ob=new Scanner(System.in);
}
class Ellipse implements GeometricFigure{
   int a,b;
   Ellipse(int a,int b)
   {
      this.a=a;
      this.b=b;
   }
   public void area()
   {
     System.out.println("Area = "+a*b);
   }
    public void setDimensions()
   {
      System.out.println("Input the new dimensions:");
      a=ob.nextInt();
      b=ob.nextInt();

   }
}
class Rectangle implements GeometricFigure{
   int a,b;
   Rectangle(int a,int b)
    {
         this.a=a;
         this.b=b;
    }
   public void area()
   {
      System.out.println("Area is = "+a*b);
   }
   public void setDimensions()
   {
      System.out.println("enter a new dimensions:");
      a=ob.nextInt();
      b=ob.nextInt();
   }
}
class Square extends Rectangle{
   int a,b;
   Square(int a,int b)
   {
      super(a,b);
      a=b;
   }
   public void setDimensions()
   {
      System.out.println("Input side length");
      a=ob.nextInt();
      b=a;
   }

}
public class Mainseventh
{
   public static void main(String args[])
   {
      Scanner ob=new Scanner(System.in);
      System.out.println("enter the  dimensions for ellipse");
      int a=ob.nextInt();
      int b=ob.nextInt();
      Ellipse ab=new Ellipse(a,b);
      ab.area();
      ab.setDimensions();
      ab.area();
      System.out.println("Input dimensions for rectangle :");
      int c=ob.nextInt();
      int d=ob.nextInt();
      Rectangle abc=new Rectangle(c,d);
      abc.area();
      abc.setDimensions();
      abc.area();
      System.out.println("enter the side length for square");
      int l=ob.nextInt();
      Square sq=new Square(l,l);
      sq.area();
      sq.setDimensions();
      sq.area();
   }
}