import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;
import java.time.LocalDate;
public class Java extends Application {
public void start(Stage s)
{
s.setTitle("Demonstrate Menus");
Menu m = new Menu("File");
MenuItem m1 = new MenuItem("Open");
MenuItem m2 = new MenuItem("Close");
MenuItem m3 = new MenuItem("Save"); 
 MenuItem m4 = new MenuItem("Exit");
m.getItems().add(m1);
m.getItems().add(m2);
m.getItems().add(m3);
 m.getItems().add(m4);

 Menu n = new Menu("Options");
 MenuItem helpmenu1=new MenuItem("op");
 n.getItems().add(helpmenu1);
 Menu l = new Menu("Help");
 MenuItem helpmenu2=new MenuItem("hlp");
 l.getItems().add(helpmenu2);
MenuBar mb = new MenuBar();
mb.getMenus().addAll(m,n,l);
VBox vb = new VBox(mb);
Scene sc = new Scene(vb, 500, 300);
s.setScene(sc);
s.show();
} 
public static void main(String args[])
{
launch(args);
}
}