import java.util.*;
class Department{
protected String department_name;
protected String HOD_name;
protected int total_students;
protected int no_of_sections;
public Department(String department_name, String HOD_name, int total_students, int no_of_sections){
this.department_name = department_name;
this.HOD_name = HOD_name;
this.total_students = total_students;
this.no_of_sections = no_of_sections;
}
public void showDepartmentDetails(){
System.out.println("Department: " + department_name);
System.out.println("HOD: " + HOD_name);
System.out.println("Students: " + total_students);
System.out.println("Sections: " + no_of_sections);
}
}
interface Publication{
public int journal_count =372;
public int project_count=125;
public int pattern_count=75;
public void showPublicationDetails();
}
class StaffMember extends Department implements Publication{
Scanner sc = new Scanner(System.in);
private String staffName;
private int staffId;
private String staffQualification;
private String designation;
private int experience;
StaffMember(String department_name, String HOD_name, int total_students, int
no_of_sections,String staffName, int staffId, String staffQualification, String
designation, int experience){
super(department_name,HOD_name,total_students,no_of_sections);
this.staffName = staffName;
this.staffId = staffId;
this.staffQualification = staffQualification;
this.designation = designation;
this.experience = experience;
}
public void showPublicationDetails(){
System.out.println("Journals: " + journal_count);
System.out.println("Projects: " + project_count);
System.out.println("Patterns: " + pattern_count);
}
public void showStaffDetails(){
System.out.println("Staff Name: " + staffName);
System.out.println("Staff ID: " + staffId);
System.out.println("Staff Qualification: " + staffQualification);
System.out.println("Designation: " + designation);
System.out.println("Experience: " + experience);
}
}
public class Mainfifteeth {
public static void main(String[] args){
StaffMember s1 = new StaffMember("cse", "Dr.alex", 55, 3, "BSomu",452, "PhD cse", "Dr.", 11);
s1.showDepartmentDetails();
s1.showStaffDetails();
s1.showPublicationDetails();
StaffMember s2 = new StaffMember("cse", "Dr.alex", 55, 3, "aRakesh",782, "MSc cse", "Mr.", 7);
s2.showDepartmentDetails();
s2.showStaffDetails();
s2.showPublicationDetails();
StaffMember s3 = new StaffMember("cse", "Dr.alex", 55, 3, "xalec",59, "MSc cse", "Mr.", 5);
s3.showDepartmentDetails();
s3.showStaffDetails();
s3.showPublicationDetails();
StaffMember s4 = new StaffMember("cse", "Dr.alex", 65, 3, "Seenau",852, "PhD cse", "Dr.", 11);
s4.showDepartmentDetails();
s4.showStaffDetails();
s4.showPublicationDetails();
StaffMember s5 = new StaffMember("cse", "Dr.alex", 55, 3, "Ravm",569,"BSc cse", "Mr.", 4);
s5.showDepartmentDetails();
s5.showStaffDetails();
s5.showPublicationDetails();
StaffMember s6 = new StaffMember("cse", "Dr.alex", 55, 3, "Jany",556, "BSc cse", "Miss", 5);
s6.showDepartmentDetails();
s6.showStaffDetails();
s6.showPublicationDetails();
StaffMember s7 = new StaffMember("cse", "Dr.alex", 55, 3, "jrRobertDowney", 652, "PhD cse", "Dr.", 14);
s7.showDepartmentDetails();
s7.showStaffDetails();
s7.showPublicationDetails();
StaffMember s8 = new StaffMember("cse", "Dr.alex", 55, 3, "johnScarlet",512, "MSc cse", "Mrs.", 8);
s8.showDepartmentDetails();
s8.showStaffDetails();
s8.showPublicationDetails();
StaffMember s9 = new StaffMember("cse", "Dr.alex", 55, 3, "wandaVision",547, "BSc cse", "Mr.", 4);
s9.showDepartmentDetails();
s9.showStaffDetails();
s9.showPublicationDetails();
StaffMember s10 = new StaffMember("cse", "Dr.alex", 55, 3, "Jobless",134, "Diploma", "Mr.", 1);
s10.showDepartmentDetails();
s10.showStaffDetails();
s10.showPublicationDetails();
StaffMember s11 = new StaffMember("cse", "Dr.alex", 55, 3, "Jeff",154, "MSc ece", "Mr.", 5);
s11.showDepartmentDetails();
s11.showStaffDetails();
s11.showPublicationDetails();
StaffMember s12 = new StaffMember("ece", "Dr.alex", 55, 3, "Him",753, "PhD ece", "Dr.", 5);
s12.showDepartmentDetails();
s12.showStaffDetails();
s12.showPublicationDetails();
StaffMember s13 = new StaffMember("ece", "Dr.alex", 55, 3, "Say",754, "BSc ece", "Mrs.", 10);
s13.showDepartmentDetails();
s13.showStaffDetails();
s13.showPublicationDetails();
StaffMember s14 = new StaffMember("Math", "Dr.alex", 55, 3, "Italy",180, "PhD Math", "Dr.", 11);
s14.showDepartmentDetails();
s14.showStaffDetails();
s14.showPublicationDetails();
StaffMember s15 = new StaffMember("Statistics", "Dr.alex", 55, 3, "Sus",452, "BSc Statistics", "Mr.", 2);
s15.showDepartmentDetails();
s15.showStaffDetails();
s15.showPublicationDetails();
}
}
