import java.util.*;
class Main
{
public static void main(String arg[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter no of rows :");
int row=sc.nextInt();
System.out.println("Enter no of columns :");
int col=sc.nextInt();
int mat[][]=new int [row][col];
System.out.println("Enter the elements :");
int i,j;
for (i=0; i<row; i++)
{
for (j=0; j<col; j++)
{
mat[i][j]=sc.nextInt();
}
}
try
{
if(row!=col)
{
throw new NotASQuareMatrix();
}
else
{
if (CheckSym(mat,row,col))
{
System.out.println("Its a square and symmetric Matrix");
}
else
{
throw new AsymmetricMatrixFoundException();
}
}
}
catch(NotASQuareMatrix e)
{
System.out.println(e);
}
catch(AsymmetricMatrixFoundException e)
{
System.out.println(e);
}
}
static void transpose(int mat[][], int n[][], int row, int col)
{
int i;
int j;
for (i=0; i<row; i++)
{
for (j=0; j<col; j++)
{
n[i][j]=mat[j][i];
}
}
}
static boolean CheckSym(int mat[][],int row,int col)
{
int i;
int j;
int n[][]=new int[row][col];
transpose(mat,n,row,col);
for (i=0; i<row; i++)
{
for (j=0; j<col; j++)
{
if(n[i][j]!=mat[i][j])
return false;
}
}
return true;
}
}
class AsymmetricMatrixFoundException extends Exception
{
public String toString()
{
return("AsymmetricMatrixFoundException");
}
}
class NotASQuareMatrix extends Exception
{
public String toString()
{
return("NotASQuareMatrix");
}
}