import java.util.*;
class T1 extends Thread
{
  static Scanner in=new Scanner(System.in);
  static int v;
  static int a[][];
  public void run()
  {
  System.out.println("Enter no.of vertices of graph");
  v=in.nextInt();
  a=new int[v][v];
  System.out.println("Enter the adjacency matrix:");
  for(int i=0;i<v;i++)
  {
    for(int j=0;j<v;j++)
    {
      a[i][j]=in.nextInt();
    }
  }
  T2 t2=new T2(a,v);
  t2.start();
  try {
     Thread.sleep(1000);
   } catch (InterruptedException ex) {}
  } 
  
  
}
class T2 extends Thread
{
  static int count,v;
  static int d[][],adjacent[][];
  T2(int a[][],int v)
  {
    this.v=v;
    for(int i=0;i<v;i++)
    {
      for(int j=0;j<v;j++)
      {
        adjacent[i][j]=a[i][j];
      }
    }
  }
  public void run()
  {
    for(int i=0;i<v;i++)
    {
      for(int j=0;j<v;j++)
      {
        d[i][j]=0;
      }
    }
    
    for(int i=0;i<v;i++)
    {
      count=0;
      for(int j=0;j<v;j++)
      {
        if(adjacent[i][j]==1)
        {
          count++;
        }
      }
      d[i][i]=count;
    }
    System.out.println();
    System.out.println("The degree matrix:");
    for(int i=0;i<v;i++)
    {
      for(int j=0;j<v;j++)
      {
        System.out.print(d[i][j]+" ");
      }
      System.out.println();
    }
    T3 t3=new T3(adjacent,d,v);
    t3.start();
    try {
     Thread.sleep(1000);
     } catch (InterruptedException ex) {}
  
  }
}
class T3 extends Thread
{
  
  static int l[][],adjacent[][],d[][],v;
  T3(int adjacent[][],int d[][],int v)
  {
    this.v=v;
    for(int i=0;i<v;i++)
    {
      for(int j=0;j<v;j++)
      {
        this.adjacent[i][j]=adjacent[i][j];
        this.d[i][j]=d[i][j];
      }
    }
  }
    
  public void run()
  {
    for(int i=0;i<v;i++)
    {
      for(int j=0;j<v;j++)
      {
        l[i][j]=d[i][j]-adjacent[i][j];
      }
    }
    System.out.println("Laplacian Matrix:");
    for(int i=0;i<v;i++)
    {
      for(int j=0;j<v;j++)
      {
        System.out.print(l[i][j]+" ");
      }
    }
  }
}
class ThreadMain
{
  public static void main(String args[])
  {
  T1 t1=new T1();
  t1.start();
  try {
     Thread.sleep(1000);
     } catch (InterruptedException ex) {}
  }
}