import java.util.*;
public class Genericsone {
  public static <A extends Comparable<A>> void Ascending(A []x) {
    A ar[] = x; 
   Arrays.sort(ar); 
  for(int i=0;i<ar.length;i++){
      System.out.print(ar[i]+" ");
  }System.out.println();} 
  public static void main(String args[]) {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter Size of the array");
      int a = sc.nextInt();
      Integer arr[] = new Integer[a];
      System.out.println("Enter the integer elements of the array");
      for(int i=0;i<a;i++)
      {
          arr[i]=sc.nextInt();
      }
  Ascending(arr);
  }
}