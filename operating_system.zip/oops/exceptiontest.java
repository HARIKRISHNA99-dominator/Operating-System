import java.util.*;
class ExceptionLineTooLong extends Exception{
public ExceptionLineTooLong(String message){
super(message);
}
 }
public class exceptiontest{
public static void main(String args[]){
Scanner sc = new Scanner(System.in);
try{
       String a = " ";
	   System.out.println("enter a string : ");
	   a = sc.nextLine();
	   int b = a.length();
	   checkLength(b);
        
}
catch(ExceptionLineTooLong ab){
           System.out.println(ab.getMessage());
		   }
}
public static int checkLength(int i)throws ExceptionLineTooLong{
if(i>=80){
           throw new ExceptionLineTooLong("its more than 80 words ....");
}
return i;
}

}