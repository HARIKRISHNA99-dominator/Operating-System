abstract class Animal
{ 
    
    public abstract void eat (Object ob);
}

 abstract class Swimmer extends Animal
{ 
    public abstract void swim();
}

 class Shark extends Swimmer
{ 
    
    
    public void swim()
{
    
    System.out.println ("shark is swimming");
}

    public void eat (Object ob)
 { 
    
    System.out.println ("shark eats " + ob.toString());
    
 }
    public String toString()
{ 
    
    return "food";
    
}

}
 
 class Tuna extends Swimmer
 
{ 
    public void swim()
{ 
    
    System.out.println ("tuna is swimming");
}

    public void eat (Object ob)
    { 
        System.out.println ("tuna eats " + ob.toString());
    }
    public String toString()
    
    { 
        return "food";

        
    }
}
         class Propoise extends Swimmer
        { public void swim()
            { 
                System.out.println ("Propoise is swimming");
            }
        public void eat (Object ob)
            { 
                System.out.println ("Propoise eats " + ob.toString());
                }
public String toString()
{ return "food";
}
}

public class Mainone
{   
    
	public static void main(String[] args) {
		Shark shrk = new Shark();
		Shark ob = new Shark();
        shrk.swim();
         shrk.eat(ob);
         
         Tuna tun = new Tuna();
		Tuna tn = new Tuna();
        tun.swim();
         tun.eat(tn);
         
         Propoise prop = new Propoise();
		Propoise pr = new Propoise();
        prop.swim();
         prop.eat(pr);
    
	}
}