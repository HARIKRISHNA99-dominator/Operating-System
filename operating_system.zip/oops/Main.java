class circle{
    double r;
    
    public circle(double r){
        this.r=r;
    }
    double getArea(double r){
        return 3.14*r*r;
    }
     public void setRadius(double r) {
      this.r = r;
      
   }
   
    public double getRadius() {
      return this.r;
      
   }
   
}

class Cylinder extends circle{
    
   
    double h;
     public Cylinder(double r,double h) {
      super(r);  
      this.h = h;
      
   }
   public void setHeight(double h) {
      this.h = h;
   }
   
     public double getHeight() {
      return this.h;
   }
    double getArea(double r,double h){
        
        return 2*3.14*r*h+2*3.14*r*r;
    }
    
}

public class Main
{
	public static void main(String[] args) {
	    circle cir = new circle(5);
	    Cylinder cyl = new Cylinder(5,3);
	    
	    System.out.println(cir.getArea(5));
	    
	    System.out.println(cyl.getArea(5,3));
	}
}