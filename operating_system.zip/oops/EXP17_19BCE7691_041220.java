import java.util.*;
class Add implements Runnable
{
	int[][] a;
	int[][] b;
	Add(int[][] a,int[][] b)
	{
		this.a=a;
		this.b=b;
		
	}
	public void run()
	{
		
		if(a.length==b.length && a[0].length==b[0].length)
		{
			int [][]sum=new int[a.length][a[0].length];
			for(int i=0;i<a.length;i++)
				for(int j=0;j<b[0].length;j++)
					sum[i][j]=a[i][j]+b[i][j];
			System.out.println("Addition Matrix");
			for(int i=0;i<sum.length;i++)
			{
				for(int j=0;j<sum[0].length;j++)
				{
					System.out.print(sum[i][j]+"  ");
				}
				System.out.println();
			}
		}
		else
		{
			System.out.println("Wrong Dimmension");
		}
	}
}
class Mult implements Runnable
{
	int[][] a;
	int[][] b;
	Mult(int[][] a,int[][] b)
	{
		this.a=a;
		this.b=b;
	}
	public void run()
	{
		if(a[0].length==b.length)
		{
			int[][] pro=new int[a.length][b[0].length];
			for(int i=0;i<a.length;i++)
				for(int j=0;j<b[0].length;j++)
					for(int k=0;k<b.length;k++)
						pro[i][j] += a[i][k] * b[k][j]; 
			System.out.println("Multiplication Matrix");
			for(int i=0;i<pro.length;i++)
			{
				for(int j=0;j<pro[0].length;j++)
				{
					System.out.print(pro[i][j]+"  ");
				}
				System.out.println();
			}
		}
		else
		{
			System.out.println("Wrong Dimmension");
		}
	}
}
public class EXP17_19BCE7691_041220
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter dimensions of array: ");
		System.out.print("Row: ");
		int r1=sc.nextInt();
		System.out.print("Col: ");
		int c1=sc.nextInt();
		int[][] arr1=new int[r1][c1];
		System.out.println("Enter values of array: ");
		for(int i=0;i<r1;i++)
			for(int j=0;j<c1;j++)
				arr1[i][j]=sc.nextInt();
		System.out.println("Enetr dimensions of other array: ");
		System.out.print("Row: ");
		int r2=sc.nextInt();
		System.out.print("Column: ");
		int c2=sc.nextInt();
		int[][] arr2=new int[r2][c2];
		System.out.println("Enter values of other array: ");
		for(int i=0;i<r1;i++)
			for(int j=0;j<c1;j++)
				arr2[i][j]=sc.nextInt();
		Add t1=new Add(arr1,arr2);
		Thread T1=new Thread(t1);
		Mult t2=new Mult(arr1,arr2);
		Thread T2=new Thread(t2);
		T1.start();
		try
        { 
            System.out.println("Current Thread: "
                  + Thread.currentThread().getName()); 
            T1.join(); 
        } 
  
        catch(Exception ex) 
        { 
            System.out.println("Exception has " + 
                                "been caught" + ex); 
        } 
		T2.start();
	}
}