import java.util.*;
public class perfectNumberone
{
	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		try{
		    perfectNumber(n);
		    
		}
		catch(Exception m){
		    System.out.println("Exception occured:"+m);
		}
	}
	static void perfectNumber(int n) throws PerfectNumberFound
	{
	    int sum = 0;
	   	for(int i = 1;i<n;i++)
		{
		    if(n%i == 0)
		    {
		        
		        sum+=i;
		    }
		}
		
		if(sum == n)
		{
		    throw new PerfectNumberFound("This is a perfect number");
		} 
		else{
		    System.out.println("This is not a perfect number");
		}
	}
}
class PerfectNumberFound extends Exception{
    PerfectNumberFound(String s){
        super(s);
    }
}