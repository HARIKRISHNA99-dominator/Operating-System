import java.util.*;
public class Mainfourth
{

   static int n=0;
   static int N=n;
   static boolean isMagicSquare(int mat[][]) {
      int flag=0;
      int gsum=0;
      for(int i=0;i<mat.length;i++)
      {
         gsum=gsum+mat[0][i];
      }

      int sum2=0;
      int sum1=0;
      for(int i=0;i<mat.length;i++)
      {
         for(int j=0;j<mat.length;j++) {
            sum2 = sum2 + mat[i][j];
            sum1=sum1+mat[j][i];
         }
         if(sum2!=gsum||sum1!=gsum)
         {
            flag=1;
         }
         sum1=0;
         sum2=0;
      }
      int sum3=0;
      int sum4=0;
      for(int i=0;i<mat.length;i++)
      {
         sum3=sum3+mat[i][i];
      }
      if(sum3!=gsum)
      {
         flag=1;
      }
      for(int i=0;i<mat.length;i++)
      {
         sum4=sum4+mat[i][mat.length-i-1];
      }
      if(sum4!=gsum)
      {
        flag=1;
      }
      if(flag==0)
      {
         return true;
      }
      else
      {
         return false;
      }
   }
   public static void main(String[] args)
   {
      Scanner ob=new Scanner(System.in);
      System.out.println("Enter the dimension");
      n=ob.nextInt();
      int mat[][]=new int[n][n];
      for(int i=0;i<n;i++)
      {
         for(int j=0;j<n;j++)
         {
            mat[i][j]=ob.nextInt();
         }
      }
      if (isMagicSquare(mat))
         System.out.println("Magic Square");
      else
         System.out.println("Not a magic" +
                 " Square");
   }
}