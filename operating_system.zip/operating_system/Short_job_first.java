import java.util.*;
 public class Short_job_first {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println ("Enter the number of process:");
		int n = sc.nextInt();
		int pid[] = new int[n];
		int arrival_time[] = new int[n];
		int burst_time[] = new int[n]; 
		int complete_time[] = new int[n]; 
		int turn_around[] = new int[n]; 
		int waiting_time[] = new int[n];
		int flag[] = new int[n];  
		int st=0, tot=0;
		float average_waiting_time=0, average_turnaround_time=0;
 
		for(int i=0;i<n;i++)
		{
			System.out.println ("Enter process " + (i+1) + " arrival time:");
			arrival_time[i] = sc.nextInt();
			System.out.println ("Enter process " + (i+1) + " brust time:");
			burst_time[i] = sc.nextInt();
			pid[i] = i+1;
			flag[i] = 0;
		}
		
		boolean a = true;
		while(true)
		{
			int c=n, min=999;
			
			if (tot == n)
				break;
			
			for (int i=0; i<n; i++)
			{
				if ((arrival_time[i] <= st) && (flag[i] == 0) && (burst_time[i]<min))
				{
					min=burst_time[i];
					c=i;
				}
			}
			
			if (c==n) 
				st++;
			else
			{
				complete_time[c]=st+burst_time[c];
				st+=burst_time[c];
				turn_around[c]=complete_time[c]-arrival_time[c];
				waiting_time[c]=turn_around[c]-burst_time[c];
				flag[c]=1;
				tot++;
			}
		}
		
		System.out.println("pid  arrival brust  complete turn waiting");
		for(int i=0;i<n;i++)
		{
			average_waiting_time+= waiting_time[i];
			average_turnaround_time+= turn_around[i];
			System.out.println(pid[i]+"\t"+arrival_time[i]+"\t"+burst_time[i]+"\t"+complete_time[i]+"\t"+turn_around[i]+"\t"+waiting_time[i]);
		}
		System.out.println ("average turnaround_time  "+ (float)(average_turnaround_time/n));
		System.out.println ("average waiting_time "+ (float)(average_waiting_time/n));
		sc.close();
	}
}